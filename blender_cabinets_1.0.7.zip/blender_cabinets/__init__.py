# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Blender Cabinets",
    "author" : "Leo Baker", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 7),
    "location" : "N-Panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Cabinets" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
class SNA_MT_1D868(bpy.types.Menu):
    bl_idname = "SNA_MT_1D868"
    bl_label = "Create Object"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=2)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)


class SNA_MT_25C6C(bpy.types.Menu):
    bl_idname = "SNA_MT_25C6C"
    bl_label = "NURBs Create"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=2)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.nurbs_cube_6156a', text='NURBs Cube', icon_value=326, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_torus_add', text='NURBs Torus', icon_value=317, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_surface_add', text='NURBs Surface Patch', icon_value=314, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_sphere_add', text='NURBs Sphere', icon_value=316, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_cylinder_add', text='NURBs Cylinder', icon_value=315, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_circle_add', text='NURBs Circle', icon_value=313, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_curve_add', text='NURBs Curve', icon_value=312, emboss=True, depress=False)
        op = layout.operator('curve.smooth_x_times', text='Special Smooth', icon_value=188, emboss=True, depress=False)


def sna_add_to_topbar_ht_upper_bar_115A5(self, context):
    if not (False):
        layout = self.layout
        if (None == None):
            pass


class SNA_PT_CABINETS_61B58(bpy.types.Panel):
    bl_label = 'Cabinets'
    bl_idname = 'SNA_PT_CABINETS_61B58'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_MT_5780D(bpy.types.Menu):
    bl_idname = "SNA_MT_5780D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=3)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        op = layout.operator('sna.polygon_bf48c', text='Polygon', icon_value=160, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = layout.operator('mesh.landscape_add', text='Generate Terrain', icon_value=564, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_monkey_add', text='Monkey', icon_value=292, emboss=True, depress=False)
        op = layout.operator('sna.teapot_9f047', text='Teapot', icon_value=134, emboss=True, depress=False)
        op = layout.operator('mesh.primitive_grid_add', text='Grid', icon_value=291, emboss=True, depress=False)
        op = layout.operator('object.text_add', text='Text', icon_value=197, emboss=True, depress=False)
        op = layout.operator('curve.tree_add', text='Tree', icon_value=_icons['Tree.png'].icon_id, emboss=True, depress=False)
        op = layout.operator('mesh.add_mesh_rock', text='Rock', icon_value=494, emboss=True, depress=False)
        op = layout.operator('object.light_add', text='Point Light', icon_value=239, emboss=True, depress=False)
        op.type = 'POINT'
        op = layout.operator('sna.spawn_bigpointlight_8e245', text='Big Point Light (Cycles)', icon_value=164, emboss=True, depress=False)
        op = layout.operator('object.light_add', text='Sun Light', icon_value=239, emboss=True, depress=False)
        op.type = 'SUN'
        op = layout.operator('object.light_add', text='Spot Light', icon_value=239, emboss=True, depress=False)
        op.type = 'SPOT'
        op = layout.operator('object.light_add', text='Area Light', icon_value=239, emboss=True, depress=False)
        op.type = 'AREA'
        op = layout.operator('object.camera_add', text='Camera', icon_value=240, emboss=True, depress=False)
        op = layout.operator('object.armature_add', text='Armature', icon_value=174, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_cylinder_add', text='NURBs Cylinder', icon_value=315, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_surface_add', text='NURBs Surface', icon_value=243, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_sphere_add', text='NURBs Sphere', icon_value=316, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_torus_add', text='NURBs Torus', icon_value=317, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_circle_add', text='NURBs Circle', icon_value=324, emboss=True, depress=False)
        op = layout.operator('surface.primitive_nurbs_surface_curve_add', text='NURBs Curve', icon_value=312, emboss=True, depress=False)
        op = layout.operator('sna.nurbs_cube_6156a', text='NURBs Cube', icon_value=326, emboss=True, depress=False)
        op = layout.operator('sna.spawn_terrain_193ff', text='NURBs Terrain', icon_value=564, emboss=True, depress=False)


class SNA_MT_A5125(bpy.types.Menu):
    bl_idname = "SNA_MT_A5125"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=2)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('object.quick_fur', text='Fur', icon_value=474, emboss=True, depress=False)
        op = layout.operator('object.quick_explode', text='Explode', icon_value=348, emboss=True, depress=False)
        op = layout.operator('object.quick_smoke', text='Smoke', icon_value=472, emboss=True, depress=False)
        op = layout.operator('object.quick_liquid', text='Liquid', icon_value=478, emboss=True, depress=False)


class SNA_MT_040C3(bpy.types.Menu):
    bl_idname = "SNA_MT_040C3"
    bl_label = "ForceFields_List"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=3)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('object.effector_add', text='Force', icon_value=245, emboss=True, depress=False)
        op.type = 'FORCE'
        op = layout.operator('object.effector_add', text='Wind', icon_value=339, emboss=True, depress=False)
        op.type = 'WIND'
        op = layout.operator('object.effector_add', text='Vortex', icon_value=340, emboss=True, depress=False)
        op.type = 'VORTEX'
        op = layout.operator('object.effector_add', text='Magnet', icon_value=341, emboss=True, depress=False)
        op.type = 'MAGNET'
        op = layout.operator('object.effector_add', text='Magnet', icon_value=342, emboss=True, depress=False)
        op.type = 'HARMONIC'
        op = layout.operator('object.effector_add', text='Magnet', icon_value=343, emboss=True, depress=False)
        op.type = 'CHARGE'
        op = layout.operator('object.effector_add', text='LennardJ', icon_value=344, emboss=True, depress=False)
        op.type = 'LENNARDJ'
        op = layout.operator('object.effector_add', text='Texture', icon_value=345, emboss=True, depress=False)
        op.type = 'TEXTURE'
        op = layout.operator('object.effector_add', text='Curve Guide', icon_value=346, emboss=True, depress=False)
        op.type = 'GUIDE'
        op = layout.operator('object.effector_add', text='Boid', icon_value=347, emboss=True, depress=False)
        op.type = 'BOID'
        op = layout.operator('object.effector_add', text='Turbulence', icon_value=348, emboss=True, depress=False)
        op.type = 'TURBULENCE'
        op = layout.operator('object.effector_add', text='Drag', icon_value=349, emboss=True, depress=False)
        op.type = 'DRAG'
        op = layout.operator('object.effector_add', text='Fluid', icon_value=350, emboss=True, depress=False)
        op.type = 'FLUID'


def sna_add_to_view3d_mt_editor_menus_27952(self, context):
    if not (False):
        layout = self.layout
        if (bpy.context.region.alignment == 'TOP'):
            pass


class SNA_OT_Nurbs_Cube_6156A(bpy.types.Operator):
    bl_idname = "sna.nurbs_cube_6156a"
    bl_label = "NURBs Cube"
    bl_description = "construct a Nurbs surface Cube"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Custom_Objects.blend') + r'\Object', filename='NURBs Cube', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_ABAFF = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active = appended_ABAFF
        appended_ABAFF.location = bpy.context.scene.cursor.location
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Teapot_9F047(bpy.types.Operator):
    bl_idname = "sna.teapot_9f047"
    bl_label = "Teapot"
    bl_description = "construct a Teapot"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Custom_Objects.blend') + r'\Object', filename='Teapot', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_7B2D0 = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active = appended_7B2D0
        appended_7B2D0.location = bpy.context.scene.cursor.location
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Polygon_Bf48C(bpy.types.Operator):
    bl_idname = "sna.polygon_bf48c"
    bl_label = "Polygon"
    bl_description = "construct a Polygon"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Custom_Objects.blend') + r'\Object', filename='Polygon', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_D9DD1 = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active = appended_D9DD1
        appended_D9DD1.location = bpy.context.scene.cursor.location
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Spawn_Terrain_193Ff(bpy.types.Operator):
    bl_idname = "sna.spawn_terrain_193ff"
    bl_label = "Spawn Terrain"
    bl_description = "construct a Nurbs Terrain surface patch"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Custom_Objects.blend') + r'\Object', filename='NURBs Terrain', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_AB06C = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active = appended_AB06C
        appended_AB06C.location = bpy.context.scene.cursor.location
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Spawn_Bigpointlight_8E245(bpy.types.Operator):
    bl_idname = "sna.spawn_bigpointlight_8e245"
    bl_label = "Spawn BigPointlight"
    bl_description = "Add a light object to the scene: Big Point"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Custom_Objects.blend') + r'\Object', filename='Big PointLight', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_4F033 = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active = appended_4F033
        appended_4F033.location = bpy.context.scene.cursor.location
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_EDITING_OPTIONS_9833F(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_9833F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_ARMATURE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_34BC2 = layout.row(heading='Custom', align=False)
        row_34BC2.alert = False
        row_34BC2.enabled = True
        row_34BC2.active = True
        row_34BC2.use_property_split = False
        row_34BC2.use_property_decorate = False
        row_34BC2.scale_x = 1.0
        row_34BC2.scale_y = 1.0
        row_34BC2.alignment = 'Expand'.upper()
        if not True: row_34BC2.operator_context = "EXEC_DEFAULT"
        op = row_34BC2.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        op = row_34BC2.operator('armature.symmetrize', text='Symmetrize', icon_value=0, emboss=True, depress=False)
        row_F17EE = layout.row(heading='Custom', align=False)
        row_F17EE.alert = False
        row_F17EE.enabled = True
        row_F17EE.active = True
        row_F17EE.use_property_split = False
        row_F17EE.use_property_decorate = False
        row_F17EE.scale_x = 1.0
        row_F17EE.scale_y = 1.0
        row_F17EE.alignment = 'Expand'.upper()
        if not True: row_F17EE.operator_context = "EXEC_DEFAULT"
        op = row_F17EE.operator('armature.roll_clear', text='Clear bone roll', icon_value=0, emboss=True, depress=False)
        row_ADBC0 = layout.row(heading='Custom', align=False)
        row_ADBC0.alert = False
        row_ADBC0.enabled = True
        row_ADBC0.active = True
        row_ADBC0.use_property_split = False
        row_ADBC0.use_property_decorate = False
        row_ADBC0.scale_x = 1.0
        row_ADBC0.scale_y = 1.0
        row_ADBC0.alignment = 'Expand'.upper()
        if not True: row_ADBC0.operator_context = "EXEC_DEFAULT"
        op = row_ADBC0.operator('armature.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        row_FE484 = layout.row(heading='Custom', align=False)
        row_FE484.alert = False
        row_FE484.enabled = True
        row_FE484.active = True
        row_FE484.use_property_split = False
        row_FE484.use_property_decorate = False
        row_FE484.scale_x = 1.0
        row_FE484.scale_y = 1.0
        row_FE484.alignment = 'Expand'.upper()
        if not True: row_FE484.operator_context = "EXEC_DEFAULT"
        op = row_FE484.operator('armature.switch_direction', text='Switch direction', icon_value=0, emboss=True, depress=False)
        row_E548E = layout.row(heading='Custom', align=False)
        row_E548E.alert = False
        row_E548E.enabled = True
        row_E548E.active = True
        row_E548E.use_property_split = False
        row_E548E.use_property_decorate = False
        row_E548E.scale_x = 1.0
        row_E548E.scale_y = 1.0
        row_E548E.alignment = 'Expand'.upper()
        if not True: row_E548E.operator_context = "EXEC_DEFAULT"
        op = row_E548E.operator('armature.autoside_names', text='Auto-Name by Axis', icon_value=0, emboss=True, depress=False)
        row_3632C = layout.row(heading='Change Bone name', align=False)
        row_3632C.alert = False
        row_3632C.enabled = True
        row_3632C.active = True
        row_3632C.use_property_split = False
        row_3632C.use_property_decorate = False
        row_3632C.scale_x = 1.0
        row_3632C.scale_y = 1.0
        row_3632C.alignment = 'Expand'.upper()
        if not True: row_3632C.operator_context = "EXEC_DEFAULT"
        row_3632C.prop(bpy.context.active_bone.id_data.edit_bones.active, 'name', text='', icon_value=0, emboss=True)
        row_82DC6 = layout.row(heading='Bone roll', align=False)
        row_82DC6.alert = False
        row_82DC6.enabled = True
        row_82DC6.active = True
        row_82DC6.use_property_split = False
        row_82DC6.use_property_decorate = False
        row_82DC6.scale_x = 1.0
        row_82DC6.scale_y = 1.0
        row_82DC6.alignment = 'Expand'.upper()
        if not True: row_82DC6.operator_context = "EXEC_DEFAULT"
        row_82DC6.prop(bpy.context.active_bone.id_data.edit_bones.active, 'roll', text='', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'use_deform', text='Use Deform', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone, 'envelope_distance', text='Envolope distance', icon_value=0, emboss=True, expand=False, slider=False, toggle=False)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'envelope_weight', text='Envelope Weight', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'head_radius', text='Head Radius', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'tail_radius', text='Tail Radius', icon_value=0, emboss=True)


class SNA_PT_RELATIONS_661BC(bpy.types.Panel):
    bl_label = 'Relations'
    bl_idname = 'SNA_PT_RELATIONS_661BC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_ARMATURE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.active_bone, 'use_connect', text='Connected', icon_value=0, emboss=True)


class SNA_PT_UV_UNWRAP_84AEC(bpy.types.Panel):
    bl_label = 'UV unwrap'
    bl_idname = 'SNA_PT_UV_UNWRAP_84AEC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 5
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_E8808 = layout.row(heading='Custom', align=False)
        row_E8808.alert = False
        row_E8808.enabled = True
        row_E8808.active = True
        row_E8808.use_property_split = False
        row_E8808.use_property_decorate = False
        row_E8808.scale_x = 1.0
        row_E8808.scale_y = 1.0
        row_E8808.alignment = 'Expand'.upper()
        if not True: row_E8808.operator_context = "EXEC_DEFAULT"
        op = row_E8808.operator('uv.unwrap', text='UV Unwrap', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.smart_project', text='Smart UV', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.reset', text='Reset', icon_value=0, emboss=True, depress=False)
        row_1A9D4 = layout.row(heading='Custom', align=False)
        row_1A9D4.alert = False
        row_1A9D4.enabled = True
        row_1A9D4.active = True
        row_1A9D4.use_property_split = False
        row_1A9D4.use_property_decorate = False
        row_1A9D4.scale_x = 1.0
        row_1A9D4.scale_y = 1.0
        row_1A9D4.alignment = 'Expand'.upper()
        if not True: row_1A9D4.operator_context = "EXEC_DEFAULT"
        op = row_1A9D4.operator('uv.project_from_view', text='View', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = False
        op = row_1A9D4.operator('uv.project_from_view', text='View (Bounds)', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = True
        row_75840 = layout.row(heading='Custom', align=False)
        row_75840.alert = False
        row_75840.enabled = True
        row_75840.active = True
        row_75840.use_property_split = False
        row_75840.use_property_decorate = False
        row_75840.scale_x = 1.0
        row_75840.scale_y = 1.0
        row_75840.alignment = 'Expand'.upper()
        if not True: row_75840.operator_context = "EXEC_DEFAULT"
        op = row_75840.operator('mesh.mark_seam', text='Mark Seam', icon_value=0, emboss=True, depress=False)
        op = row_75840.operator('mesh.mark_seam', text='Clear Seam', icon_value=0, emboss=True, depress=False)
        op.clear = True
        row_09EC4 = layout.row(heading='Custom', align=False)
        row_09EC4.alert = False
        row_09EC4.enabled = True
        row_09EC4.active = True
        row_09EC4.use_property_split = False
        row_09EC4.use_property_decorate = False
        row_09EC4.scale_x = 1.0
        row_09EC4.scale_y = 1.0
        row_09EC4.alignment = 'Expand'.upper()
        if not True: row_09EC4.operator_context = "EXEC_DEFAULT"
        op = row_09EC4.operator('uv.cube_project', text='Cube Project', icon_value=0, emboss=True, depress=False)
        op = row_09EC4.operator('uv.sphere_project', text='Sphere Project', icon_value=0, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_3EDA7(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_3EDA7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_NORMAL_EDIT_31D41(bpy.types.Panel):
    bl_label = 'Normal Edit'
    bl_idname = 'SNA_PT_NORMAL_EDIT_31D41'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_parent_id = 'SNA_PT_EDITING_OPTIONS_3EDA7'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('mesh.flip_normals', text='Flip Normals', icon_value=0, emboss=True, depress=False)
        op = layout.operator('mesh.point_normals', text='Point Normals to Target', icon_value=0, emboss=True, depress=False)
        row_89BE7 = layout.row(heading='', align=False)
        row_89BE7.alert = False
        row_89BE7.enabled = True
        row_89BE7.active = True
        row_89BE7.use_property_split = False
        row_89BE7.use_property_decorate = False
        row_89BE7.scale_x = 1.0
        row_89BE7.scale_y = 1.0
        row_89BE7.alignment = 'Expand'.upper()
        if not True: row_89BE7.operator_context = "EXEC_DEFAULT"
        op = row_89BE7.operator('transform.rotate_normal', text='Rotate Normals', icon_value=0, emboss=True, depress=False)
        op = row_89BE7.operator('mesh.set_normals_from_faces', text='Set from faces', icon_value=0, emboss=True, depress=False)
        row_51C8E = layout.row(heading='', align=False)
        row_51C8E.alert = False
        row_51C8E.enabled = True
        row_51C8E.active = True
        row_51C8E.use_property_split = False
        row_51C8E.use_property_decorate = False
        row_51C8E.scale_x = 1.0
        row_51C8E.scale_y = 1.0
        row_51C8E.alignment = 'Expand'.upper()
        if not True: row_51C8E.operator_context = "EXEC_DEFAULT"
        op = row_51C8E.operator('mesh.normals_tools', text='Copy Vector', icon_value=0, emboss=True, depress=False)
        op.mode = 'COPY'
        op = row_51C8E.operator('mesh.normals_tools', text='Paste Vector', icon_value=0, emboss=True, depress=False)
        op.mode = 'PASTE'


class SNA_PT_CREATE_OBJECT_7870B(bpy.types.Panel):
    bl_label = 'Create Object'
    bl_idname = 'SNA_PT_CREATE_OBJECT_7870B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.menu('SNA_MT_1D868', text='Create Object', icon_value=0)


class SNA_PT_POLYGON_MERGE__SPLIT_67BA3(bpy.types.Panel):
    bl_label = 'Polygon Merge / Split'
    bl_idname = 'SNA_PT_POLYGON_MERGE__SPLIT_67BA3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_EDITING_OPTIONS_3EDA7'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_95D29 = layout.row(heading='', align=False)
        row_95D29.alert = False
        row_95D29.enabled = True
        row_95D29.active = True
        row_95D29.use_property_split = False
        row_95D29.use_property_decorate = False
        row_95D29.scale_x = 1.0
        row_95D29.scale_y = 1.0
        row_95D29.alignment = 'Expand'.upper()
        if not True: row_95D29.operator_context = "EXEC_DEFAULT"
        op = row_95D29.operator('mesh.merge', text='Center', icon_value=0, emboss=True, depress=False)
        op.type = 'CENTER'
        op = row_95D29.operator('mesh.merge', text='Cursor', icon_value=0, emboss=True, depress=False)
        op.type = 'CURSOR'
        op = row_95D29.operator('mesh.merge', text='Collapse', icon_value=0, emboss=True, depress=False)
        op.type = 'COLLAPSE'
        row_5A72A = layout.row(heading='', align=False)
        row_5A72A.alert = False
        row_5A72A.enabled = True
        row_5A72A.active = True
        row_5A72A.use_property_split = False
        row_5A72A.use_property_decorate = False
        row_5A72A.scale_x = 1.0
        row_5A72A.scale_y = 1.0
        row_5A72A.alignment = 'Expand'.upper()
        if not True: row_5A72A.operator_context = "EXEC_DEFAULT"
        op = row_5A72A.operator('mesh.split', text='Split', icon_value=0, emboss=True, depress=False)
        if bpy.context.tool_settings.mesh_select_mode[0]:
            row_C501F = layout.row(heading='', align=False)
            row_C501F.alert = False
            row_C501F.enabled = True
            row_C501F.active = True
            row_C501F.use_property_split = False
            row_C501F.use_property_decorate = False
            row_C501F.scale_x = 1.0
            row_C501F.scale_y = 1.0
            row_C501F.alignment = 'Expand'.upper()
            if not True: row_C501F.operator_context = "EXEC_DEFAULT"
            op = row_C501F.operator('mesh.merge', text='First', icon_value=0, emboss=True, depress=False)
            op.type = 'FIRST'
            op = row_C501F.operator('mesh.merge', text='Last', icon_value=0, emboss=True, depress=False)
            op.type = 'LAST'


class SNA_PT_POLYGON_EDIT_56722(bpy.types.Panel):
    bl_label = 'Polygon Edit'
    bl_idname = 'SNA_PT_POLYGON_EDIT_56722'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_EDITING_OPTIONS_3EDA7'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_08AF8 = layout.row(heading='', align=False)
        row_08AF8.alert = False
        row_08AF8.enabled = True
        row_08AF8.active = True
        row_08AF8.use_property_split = False
        row_08AF8.use_property_decorate = False
        row_08AF8.scale_x = 1.0
        row_08AF8.scale_y = 1.0
        row_08AF8.alignment = 'Expand'.upper()
        if not True: row_08AF8.operator_context = "EXEC_DEFAULT"
        op = row_08AF8.operator('mesh.faces_shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        op = row_08AF8.operator('mesh.faces_shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        row_C9C37 = layout.row(heading='', align=False)
        row_C9C37.alert = False
        row_C9C37.enabled = True
        row_C9C37.active = True
        row_C9C37.use_property_split = False
        row_C9C37.use_property_decorate = False
        row_C9C37.scale_x = 1.0
        row_C9C37.scale_y = 1.0
        row_C9C37.alignment = 'Expand'.upper()
        if not True: row_C9C37.operator_context = "EXEC_DEFAULT"
        op = row_C9C37.operator('mesh.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_58E09 = layout.row(heading='Custom', align=False)
        row_58E09.alert = False
        row_58E09.enabled = True
        row_58E09.active = True
        row_58E09.use_property_split = False
        row_58E09.use_property_decorate = False
        row_58E09.scale_x = 1.0
        row_58E09.scale_y = 1.0
        row_58E09.alignment = 'Expand'.upper()
        if not True: row_58E09.operator_context = "EXEC_DEFAULT"
        op = row_58E09.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        op = row_58E09.operator('mesh.fill', text='Fill', icon_value=0, emboss=True, depress=False)
        row_5CB8C = layout.row(heading='Custom', align=False)
        row_5CB8C.alert = False
        row_5CB8C.enabled = True
        row_5CB8C.active = True
        row_5CB8C.use_property_split = False
        row_5CB8C.use_property_decorate = False
        row_5CB8C.scale_x = 1.0
        row_5CB8C.scale_y = 1.0
        row_5CB8C.alignment = 'Expand'.upper()
        if not True: row_5CB8C.operator_context = "EXEC_DEFAULT"
        op = row_5CB8C.operator('mesh.quads_convert_to_tris', text='Quads to Tris', icon_value=0, emboss=True, depress=False)
        op = row_5CB8C.operator('mesh.tris_convert_to_quads', text='Tris to Quads', icon_value=0, emboss=True, depress=False)
        row_E2C0C = layout.row(heading='Custom', align=False)
        row_E2C0C.alert = False
        row_E2C0C.enabled = True
        row_E2C0C.active = True
        row_E2C0C.use_property_split = False
        row_E2C0C.use_property_decorate = False
        row_E2C0C.scale_x = 1.0
        row_E2C0C.scale_y = 1.0
        row_E2C0C.alignment = 'Expand'.upper()
        if not True: row_E2C0C.operator_context = "EXEC_DEFAULT"
        op = row_E2C0C.operator('mesh.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        op = row_E2C0C.operator('mesh.unsubdivide', text='Un-Subdivide', icon_value=0, emboss=True, depress=False)
        row_5540A = layout.row(heading='', align=False)
        row_5540A.alert = False
        row_5540A.enabled = True
        row_5540A.active = True
        row_5540A.use_property_split = False
        row_5540A.use_property_decorate = False
        row_5540A.scale_x = 1.0
        row_5540A.scale_y = 1.0
        row_5540A.alignment = 'Expand'.upper()
        if not True: row_5540A.operator_context = "EXEC_DEFAULT"
        op = row_5540A.operator('mesh.decimate', text='Decimate Geometry', icon_value=0, emboss=True, depress=False)
        op = row_5540A.operator('mesh.rip', text='Rip Polygon', icon_value=0, emboss=True, depress=False)
        op.release_confirm = False
        row_B40A3 = layout.row(heading='Custom', align=False)
        row_B40A3.alert = False
        row_B40A3.enabled = True
        row_B40A3.active = True
        row_B40A3.use_property_split = False
        row_B40A3.use_property_decorate = False
        row_B40A3.scale_x = 1.0
        row_B40A3.scale_y = 1.0
        row_B40A3.alignment = 'Expand'.upper()
        if not True: row_B40A3.operator_context = "EXEC_DEFAULT"
        op = row_B40A3.operator('mesh.vertices_smooth', text='Smooth Vert', icon_value=0, emboss=True, depress=False)
        op.factor = 0.5
        op = row_B40A3.operator('transform.vert_crease', text='Vertex Crease', icon_value=0, emboss=True, depress=False)
        row_79FC8 = layout.row(heading='Custom', align=False)
        row_79FC8.alert = False
        row_79FC8.enabled = True
        row_79FC8.active = True
        row_79FC8.use_property_split = False
        row_79FC8.use_property_decorate = False
        row_79FC8.scale_x = 1.0
        row_79FC8.scale_y = 1.0
        row_79FC8.alignment = 'Expand'.upper()
        if not True: row_79FC8.operator_context = "EXEC_DEFAULT"
        op = row_79FC8.operator('mesh.loopcut_slide', text='Loop cut', icon_value=0, emboss=True, depress=False)
        op = row_79FC8.operator('mesh.duplicate_move', text='Duplicate Faces', icon_value=0, emboss=True, depress=False)
        row_989A1 = layout.row(heading='Custom', align=False)
        row_989A1.alert = False
        row_989A1.enabled = True
        row_989A1.active = True
        row_989A1.use_property_split = False
        row_989A1.use_property_decorate = False
        row_989A1.scale_x = 1.0
        row_989A1.scale_y = 1.0
        row_989A1.alignment = 'Expand'.upper()
        if not True: row_989A1.operator_context = "EXEC_DEFAULT"
        op = row_989A1.operator('mesh.bevel', text='Bevel', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.screw', text='Screw', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.poke', text='Poke', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.solidify', text='Solidify', icon_value=0, emboss=True, depress=False)
        row_0073C = layout.row(heading='Custom', align=False)
        row_0073C.alert = False
        row_0073C.enabled = True
        row_0073C.active = True
        row_0073C.use_property_split = False
        row_0073C.use_property_decorate = False
        row_0073C.scale_x = 1.0
        row_0073C.scale_y = 1.0
        row_0073C.alignment = 'Expand'.upper()
        if not True: row_0073C.operator_context = "EXEC_DEFAULT"
        op = row_0073C.operator('mesh.looptools_bridge', text='Bridge', icon_value=0, emboss=True, depress=False)
        op = row_0073C.operator('mesh.looptools_circle', text='Circle', icon_value=0, emboss=True, depress=False)
        op = row_0073C.operator('mesh.looptools_flatten', text='Flatten', icon_value=0, emboss=True, depress=False)
        op = row_0073C.operator('mesh.looptools_relax', text='Relax', icon_value=0, emboss=True, depress=False)


class SNA_PT_SHORTCUTS_B61D4(bpy.types.Panel):
    bl_label = 'Shortcuts'
    bl_idname = 'SNA_PT_SHORTCUTS_B61D4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_47F4D = layout.row(heading='', align=False)
        row_47F4D.alert = False
        row_47F4D.enabled = True
        row_47F4D.active = True
        row_47F4D.use_property_split = False
        row_47F4D.use_property_decorate = False
        row_47F4D.scale_x = 1.0
        row_47F4D.scale_y = 1.0
        row_47F4D.alignment = 'Expand'.upper()
        if not True: row_47F4D.operator_context = "EXEC_DEFAULT"
        row_47F4D.prop(bpy.context.area.spaces[0].overlay, 'show_face_orientation', text='Face Direction', icon_value=0, emboss=True)
        row_47F4D.prop(bpy.context.area.spaces[0].overlay, 'show_stats', text='Statistics', icon_value=0, emboss=True)
        row_E32DD = layout.row(heading='', align=False)
        row_E32DD.alert = False
        row_E32DD.enabled = True
        row_E32DD.active = True
        row_E32DD.use_property_split = False
        row_E32DD.use_property_decorate = False
        row_E32DD.scale_x = 1.0
        row_E32DD.scale_y = 1.0
        row_E32DD.alignment = 'Expand'.upper()
        if not True: row_E32DD.operator_context = "EXEC_DEFAULT"
        row_E32DD.prop(bpy.context.area.spaces[0].overlay, 'show_split_normals', text='', icon_value=484, emboss=True)
        row_E32DD.prop(bpy.context.area.spaces[0].overlay, 'show_vertex_normals', text='', icon_value=622, emboss=True)
        row_E32DD.prop(bpy.context.area.spaces[0].overlay, 'normals_length', text='Length', icon_value=484, emboss=True)
        row_83D9A = layout.row(heading='', align=False)
        row_83D9A.alert = False
        row_83D9A.enabled = True
        row_83D9A.active = True
        row_83D9A.use_property_split = False
        row_83D9A.use_property_decorate = False
        row_83D9A.scale_x = 1.0
        row_83D9A.scale_y = 1.0
        row_83D9A.alignment = 'Expand'.upper()
        if not True: row_83D9A.operator_context = "EXEC_DEFAULT"
        op = row_83D9A.operator('view3d.collection_manager', text='', icon_value=171, emboss=True, depress=False)
        op = row_83D9A.operator('object.parent_set', text='', icon_value=173, emboss=True, depress=False)
        if bpy.context.view_layer.objects.active.type == 'MESH':
            op = row_83D9A.operator('object.mode_set', text='', icon_value=910, emboss=True, depress=False)
            op.mode = 'VERTEX_PAINT'
        if bpy.context.view_layer.objects.active.type == 'MESH':
            op = row_83D9A.operator('object.mode_set', text='', icon_value=908, emboss=True, depress=False)
            op.mode = 'TEXTURE_PAINT'
            op.toggle = False


class SNA_PT_MAIN_OBJECT_PROPERTIES_75CA3(bpy.types.Panel):
    bl_label = 'Main Object Properties'
    bl_idname = 'SNA_PT_MAIN_OBJECT_PROPERTIES_75CA3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.view_layer.objects.active, 'location', text='Move', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='Rotate', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.objects.active, 'scale', text='Scale', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.objects.active, 'name', text='Name', icon_value=0, emboss=True)
        if 'OBJECT'==bpy.context.mode:
            if bpy.context.view_layer.objects.active.type == 'MESH':
                layout.prop_search(bpy.context.object, 'data', bpy.context.blend_data, 'meshes', text='Linked', icon='NONE')


class SNA_PT_BASIC_CAMERA_PROPERTIES_74505(bpy.types.Panel):
    bl_label = 'Basic Camera Properties'
    bl_idname = 'SNA_PT_BASIC_CAMERA_PROPERTIES_74505'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_MAIN_OBJECT_PROPERTIES_75CA3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (True)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_NURBS_EDIT_813AB(bpy.types.Panel):
    bl_label = 'NURBs Edit'
    bl_idname = 'SNA_PT_NURBS_EDIT_813AB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_SURFACE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('curve.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.switch_direction', text='Switch Direction', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.cyclic_toggle', text='Toggle Cyclic', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.split', text='Split Points', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.separate', text='Seperate', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.make_segment', text='Make Segment', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.smooth', text='Smooth', icon_value=0, emboss=True, depress=False)
        op = layout.operator('object.hook_add_newob', text='Hook to Object', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.decimate', text='Decimate Curve', icon_value=0, emboss=True, depress=False)
        op = layout.operator('curve.spline_type_set', text='Spline Type', icon_value=0, emboss=True, depress=False)


class SNA_PT_CREATE_OBJECT_BA0BF(bpy.types.Panel):
    bl_label = 'Create Object'
    bl_idname = 'SNA_PT_CREATE_OBJECT_BA0BF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_SURFACE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.menu('SNA_MT_25C6C', text='Create NURBs Object', icon_value=0)


class SNA_PT_RELATIONS_3D027(bpy.types.Panel):
    bl_label = 'Relations'
    bl_idname = 'SNA_PT_RELATIONS_3D027'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_FEE98 = layout.row(heading='Custom', align=False)
        row_FEE98.alert = False
        row_FEE98.enabled = True
        row_FEE98.active = True
        row_FEE98.use_property_split = False
        row_FEE98.use_property_decorate = False
        row_FEE98.scale_x = 1.0
        row_FEE98.scale_y = 1.0
        row_FEE98.alignment = 'Expand'.upper()
        if not True: row_FEE98.operator_context = "EXEC_DEFAULT"
        op = row_FEE98.operator('object.make_single_user', text='Make Single User', icon_value=0, emboss=True, depress=False)
        op = row_FEE98.operator('object.make_local', text='Make Local User', icon_value=0, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_098E3(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_098E3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_8924B = layout.row(heading='Custom', align=False)
        row_8924B.alert = False
        row_8924B.enabled = True
        row_8924B.active = True
        row_8924B.use_property_split = False
        row_8924B.use_property_decorate = False
        row_8924B.scale_x = 1.0
        row_8924B.scale_y = 1.200000286102295
        row_8924B.alignment = 'Expand'.upper()
        if not True: row_8924B.operator_context = "EXEC_DEFAULT"
        op = row_8924B.operator('object.shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        op = row_8924B.operator('object.shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        row_33FCD = layout.row(heading='Custom', align=False)
        row_33FCD.alert = False
        row_33FCD.enabled = True
        row_33FCD.active = True
        row_33FCD.use_property_split = False
        row_33FCD.use_property_decorate = False
        row_33FCD.scale_x = 1.0
        row_33FCD.scale_y = 1.0
        row_33FCD.alignment = 'Expand'.upper()
        if not True: row_33FCD.operator_context = "EXEC_DEFAULT"
        op = row_33FCD.operator('object.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_551D7 = layout.row(heading='Custom', align=False)
        row_551D7.alert = False
        row_551D7.enabled = True
        row_551D7.active = True
        row_551D7.use_property_split = False
        row_551D7.use_property_decorate = False
        row_551D7.scale_x = 1.0
        row_551D7.scale_y = 1.0
        row_551D7.alignment = 'Expand'.upper()
        if not True: row_551D7.operator_context = "EXEC_DEFAULT"
        op = row_551D7.operator('object.convert', text='Convert To', icon_value=0, emboss=True, depress=False)
        row_A6A0D = layout.row(heading='Custom', align=False)
        row_A6A0D.alert = False
        row_A6A0D.enabled = True
        row_A6A0D.active = True
        row_A6A0D.use_property_split = False
        row_A6A0D.use_property_decorate = False
        row_A6A0D.scale_x = 1.0
        row_A6A0D.scale_y = 1.0
        row_A6A0D.alignment = 'Expand'.upper()
        if not True: row_A6A0D.operator_context = "EXEC_DEFAULT"
        op = row_A6A0D.operator('object.join', text='Join into a single mesh', icon_value=0, emboss=True, depress=False)
        row_57631 = layout.row(heading='Custom', align=False)
        row_57631.alert = False
        row_57631.enabled = True
        row_57631.active = True
        row_57631.use_property_split = False
        row_57631.use_property_decorate = False
        row_57631.scale_x = 1.0
        row_57631.scale_y = 1.0
        row_57631.alignment = 'Expand'.upper()
        if not True: row_57631.operator_context = "EXEC_DEFAULT"
        op = row_57631.operator('object.duplicate_move', text='Duplicate', icon_value=0, emboss=True, depress=False)
        op = row_57631.operator('object.duplicate_move_linked', text='Duplicate (Linked)', icon_value=0, emboss=True, depress=False)
        row_5BA4D = layout.row(heading='Custom', align=False)
        row_5BA4D.alert = False
        row_5BA4D.enabled = True
        row_5BA4D.active = True
        row_5BA4D.use_property_split = False
        row_5BA4D.use_property_decorate = False
        row_5BA4D.scale_x = 1.0
        row_5BA4D.scale_y = 1.0
        row_5BA4D.alignment = 'Expand'.upper()
        if not True: row_5BA4D.operator_context = "EXEC_DEFAULT"
        op = row_5BA4D.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        op = row_5BA4D.operator('object.origin_set', text='Set Origin', icon_value=0, emboss=True, depress=False)


class SNA_PT_ANIMATION_A84F4(bpy.types.Panel):
    bl_label = 'Animation'
    bl_idname = 'SNA_PT_ANIMATION_A84F4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('dynamic_parent.create', text='Create constraint', icon_value=0, emboss=True, depress=False)
        op = layout.operator('dynamic_parent.disable', text='Disable constraint', icon_value=0, emboss=True, depress=False)


class SNA_PT_CREATE_OBJECT_3B562(bpy.types.Panel):
    bl_label = 'Create Object'
    bl_idname = 'SNA_PT_CREATE_OBJECT_3B562'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_CABINETS_61B58'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.menu('SNA_MT_5780D', text='Create Object', icon_value=0)
        layout.menu('SNA_MT_040C3', text='Create Forcefield', icon_value=0)
        layout.menu('SNA_MT_A5125', text='Add Effect', icon_value=0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_smooth_shade = bpy.props.StringProperty(name='Smooth Shade', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_spaceview3dcontext = bpy.props.StringProperty(name='SpaceView3D.context', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_object_search = bpy.props.StringProperty(name='Object Search', description='', default='', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_MT_1D868)
    bpy.utils.register_class(SNA_MT_25C6C)
    bpy.types.TOPBAR_HT_upper_bar.append(sna_add_to_topbar_ht_upper_bar_115A5)
    bpy.utils.register_class(SNA_PT_CABINETS_61B58)
    bpy.utils.register_class(SNA_MT_5780D)
    if not 'Tree.png' in _icons: _icons.load('Tree.png', os.path.join(os.path.dirname(__file__), 'icons', 'Tree.png'), "IMAGE")
    bpy.utils.register_class(SNA_MT_A5125)
    bpy.utils.register_class(SNA_MT_040C3)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_27952)
    bpy.utils.register_class(SNA_OT_Nurbs_Cube_6156A)
    bpy.utils.register_class(SNA_OT_Teapot_9F047)
    bpy.utils.register_class(SNA_OT_Polygon_Bf48C)
    bpy.utils.register_class(SNA_OT_Spawn_Terrain_193Ff)
    bpy.utils.register_class(SNA_OT_Spawn_Bigpointlight_8E245)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_9833F)
    bpy.utils.register_class(SNA_PT_RELATIONS_661BC)
    bpy.utils.register_class(SNA_PT_UV_UNWRAP_84AEC)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_3EDA7)
    bpy.utils.register_class(SNA_PT_NORMAL_EDIT_31D41)
    bpy.utils.register_class(SNA_PT_CREATE_OBJECT_7870B)
    bpy.utils.register_class(SNA_PT_POLYGON_MERGE__SPLIT_67BA3)
    bpy.utils.register_class(SNA_PT_POLYGON_EDIT_56722)
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_SHORTCUTS_B61D4)
    bpy.utils.register_class(SNA_PT_MAIN_OBJECT_PROPERTIES_75CA3)
    bpy.utils.register_class(SNA_PT_BASIC_CAMERA_PROPERTIES_74505)
    bpy.utils.register_class(SNA_PT_NURBS_EDIT_813AB)
    bpy.utils.register_class(SNA_PT_CREATE_OBJECT_BA0BF)
    bpy.utils.register_class(SNA_PT_RELATIONS_3D027)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_098E3)
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_ANIMATION_A84F4)
    bpy.utils.register_class(SNA_PT_CREATE_OBJECT_3B562)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_object_search
    del bpy.types.Scene.sna_spaceview3dcontext
    del bpy.types.Scene.sna_smooth_shade
    bpy.utils.unregister_class(SNA_MT_1D868)
    bpy.utils.unregister_class(SNA_MT_25C6C)
    bpy.types.TOPBAR_HT_upper_bar.remove(sna_add_to_topbar_ht_upper_bar_115A5)
    bpy.utils.unregister_class(SNA_PT_CABINETS_61B58)
    bpy.utils.unregister_class(SNA_MT_5780D)
    bpy.utils.unregister_class(SNA_MT_A5125)
    bpy.utils.unregister_class(SNA_MT_040C3)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_27952)
    bpy.utils.unregister_class(SNA_OT_Nurbs_Cube_6156A)
    bpy.utils.unregister_class(SNA_OT_Teapot_9F047)
    bpy.utils.unregister_class(SNA_OT_Polygon_Bf48C)
    bpy.utils.unregister_class(SNA_OT_Spawn_Terrain_193Ff)
    bpy.utils.unregister_class(SNA_OT_Spawn_Bigpointlight_8E245)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_9833F)
    bpy.utils.unregister_class(SNA_PT_RELATIONS_661BC)
    bpy.utils.unregister_class(SNA_PT_UV_UNWRAP_84AEC)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_3EDA7)
    bpy.utils.unregister_class(SNA_PT_NORMAL_EDIT_31D41)
    bpy.utils.unregister_class(SNA_PT_CREATE_OBJECT_7870B)
    bpy.utils.unregister_class(SNA_PT_POLYGON_MERGE__SPLIT_67BA3)
    bpy.utils.unregister_class(SNA_PT_POLYGON_EDIT_56722)
    bpy.utils.unregister_class(SNA_PT_SHORTCUTS_B61D4)
    bpy.utils.unregister_class(SNA_PT_MAIN_OBJECT_PROPERTIES_75CA3)
    bpy.utils.unregister_class(SNA_PT_BASIC_CAMERA_PROPERTIES_74505)
    bpy.utils.unregister_class(SNA_PT_NURBS_EDIT_813AB)
    bpy.utils.unregister_class(SNA_PT_CREATE_OBJECT_BA0BF)
    bpy.utils.unregister_class(SNA_PT_RELATIONS_3D027)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_098E3)
    bpy.utils.unregister_class(SNA_PT_ANIMATION_A84F4)
    bpy.utils.unregister_class(SNA_PT_CREATE_OBJECT_3B562)
