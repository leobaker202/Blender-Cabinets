# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Blender Cabinets",
    "author" : "Leo Baker", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Cabinets" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def sna_add_to_view3d_mt_editor_menus_85B53(self, context):
    if not (False):
        layout = self.layout
        if (bpy.context.region.alignment == 'TOP'):
            pass


def sna_add_to_topbar_ht_upper_bar_10CBC(self, context):
    if not (False):
        layout = self.layout
        if (None == None):
            pass


class SNA_PT_CABINETS_B8B3F(bpy.types.Panel):
    bl_label = 'Cabinets'
    bl_idname = 'SNA_PT_CABINETS_B8B3F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_ADD_OBJECTS_D6F40(bpy.types.Panel):
    bl_label = 'Add Objects'
    bl_idname = 'SNA_PT_ADD_OBJECTS_D6F40'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_C5496 = layout.row(heading='Custom', align=False)
        row_C5496.alert = False
        row_C5496.enabled = True
        row_C5496.active = True
        row_C5496.use_property_split = False
        row_C5496.use_property_decorate = False
        row_C5496.scale_x = 1.0
        row_C5496.scale_y = 1.0
        row_C5496.alignment = 'Expand'.upper()
        if not True: row_C5496.operator_context = "EXEC_DEFAULT"
        op = row_C5496.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = row_C5496.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = row_C5496.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        row_0299B = layout.row(heading='Custom', align=False)
        row_0299B.alert = False
        row_0299B.enabled = True
        row_0299B.active = True
        row_0299B.use_property_split = False
        row_0299B.use_property_decorate = False
        row_0299B.scale_x = 1.0
        row_0299B.scale_y = 1.0
        row_0299B.alignment = 'Expand'.upper()
        if not True: row_0299B.operator_context = "EXEC_DEFAULT"
        op = row_0299B.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = row_0299B.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)
        op = row_0299B.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_C0293(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_C0293'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_08AF8 = layout.row(heading='Custom', align=False)
        row_08AF8.alert = False
        row_08AF8.enabled = True
        row_08AF8.active = True
        row_08AF8.use_property_split = False
        row_08AF8.use_property_decorate = False
        row_08AF8.scale_x = 1.0
        row_08AF8.scale_y = 1.5
        row_08AF8.alignment = 'Expand'.upper()
        if not True: row_08AF8.operator_context = "EXEC_DEFAULT"
        op = row_08AF8.operator('mesh.faces_shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        op = row_08AF8.operator('mesh.faces_shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        row_C9C37 = layout.row(heading='Custom', align=False)
        row_C9C37.alert = False
        row_C9C37.enabled = True
        row_C9C37.active = True
        row_C9C37.use_property_split = False
        row_C9C37.use_property_decorate = False
        row_C9C37.scale_x = 1.0
        row_C9C37.scale_y = 1.0
        row_C9C37.alignment = 'Expand'.upper()
        if not True: row_C9C37.operator_context = "EXEC_DEFAULT"
        op = row_C9C37.operator('mesh.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_58E09 = layout.row(heading='Custom', align=False)
        row_58E09.alert = False
        row_58E09.enabled = True
        row_58E09.active = True
        row_58E09.use_property_split = False
        row_58E09.use_property_decorate = False
        row_58E09.scale_x = 1.0
        row_58E09.scale_y = 1.0
        row_58E09.alignment = 'Expand'.upper()
        if not True: row_58E09.operator_context = "EXEC_DEFAULT"
        op = row_58E09.operator('mesh.flip_normals', text='Flip Normals', icon_value=0, emboss=True, depress=False)
        row_C08C8 = layout.row(heading='Custom', align=False)
        row_C08C8.alert = False
        row_C08C8.enabled = True
        row_C08C8.active = True
        row_C08C8.use_property_split = False
        row_C08C8.use_property_decorate = False
        row_C08C8.scale_x = 1.0
        row_C08C8.scale_y = 1.0
        row_C08C8.alignment = 'Expand'.upper()
        if not True: row_C08C8.operator_context = "EXEC_DEFAULT"
        op = row_C08C8.operator('mesh.merge', text='Merge Polys', icon_value=0, emboss=True, depress=False)
        op = row_C08C8.operator('mesh.split', text='Split Polys', icon_value=0, emboss=True, depress=False)
        row_6236D = layout.row(heading='Custom', align=False)
        row_6236D.alert = False
        row_6236D.enabled = True
        row_6236D.active = True
        row_6236D.use_property_split = False
        row_6236D.use_property_decorate = False
        row_6236D.scale_x = 1.0
        row_6236D.scale_y = 1.0
        row_6236D.alignment = 'Expand'.upper()
        if not True: row_6236D.operator_context = "EXEC_DEFAULT"
        op = row_6236D.operator('view3d.edit_mesh_extrude_move_normal', text='Extrude', icon_value=0, emboss=True, depress=False)
        op = row_6236D.operator('mesh.fill', text='Fill', icon_value=0, emboss=True, depress=False)
        row_5CB8C = layout.row(heading='Custom', align=False)
        row_5CB8C.alert = False
        row_5CB8C.enabled = True
        row_5CB8C.active = True
        row_5CB8C.use_property_split = False
        row_5CB8C.use_property_decorate = False
        row_5CB8C.scale_x = 1.0
        row_5CB8C.scale_y = 1.0
        row_5CB8C.alignment = 'Expand'.upper()
        if not True: row_5CB8C.operator_context = "EXEC_DEFAULT"
        op = row_5CB8C.operator('mesh.quads_convert_to_tris', text='Quads to Tris', icon_value=0, emboss=True, depress=False)
        op = row_5CB8C.operator('mesh.tris_convert_to_quads', text='Tris to Quads', icon_value=0, emboss=True, depress=False)
        row_B40A3 = layout.row(heading='Custom', align=False)
        row_B40A3.alert = False
        row_B40A3.enabled = True
        row_B40A3.active = True
        row_B40A3.use_property_split = False
        row_B40A3.use_property_decorate = False
        row_B40A3.scale_x = 1.0
        row_B40A3.scale_y = 1.0
        row_B40A3.alignment = 'Expand'.upper()
        if not True: row_B40A3.operator_context = "EXEC_DEFAULT"
        op = row_B40A3.operator('mesh.vertices_smooth', text='Smooth Vert', icon_value=0, emboss=True, depress=False)
        op = row_B40A3.operator('transform.vert_crease', text='Vertex Crease', icon_value=0, emboss=True, depress=False)
        row_989A1 = layout.row(heading='Custom', align=False)
        row_989A1.alert = False
        row_989A1.enabled = True
        row_989A1.active = True
        row_989A1.use_property_split = False
        row_989A1.use_property_decorate = False
        row_989A1.scale_x = 1.0
        row_989A1.scale_y = 1.0
        row_989A1.alignment = 'Expand'.upper()
        if not True: row_989A1.operator_context = "EXEC_DEFAULT"
        op = row_989A1.operator('mesh.bevel', text='Bevel', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.screw', text='Screw', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.poke', text='Poke', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.solidify', text='Solidify', icon_value=0, emboss=True, depress=False)
        row_E2C0C = layout.row(heading='Custom', align=False)
        row_E2C0C.alert = False
        row_E2C0C.enabled = True
        row_E2C0C.active = True
        row_E2C0C.use_property_split = False
        row_E2C0C.use_property_decorate = False
        row_E2C0C.scale_x = 1.0
        row_E2C0C.scale_y = 1.0
        row_E2C0C.alignment = 'Expand'.upper()
        if not True: row_E2C0C.operator_context = "EXEC_DEFAULT"
        op = row_E2C0C.operator('mesh.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        op = row_E2C0C.operator('mesh.unsubdivide', text='Un-Subdivide', icon_value=0, emboss=True, depress=False)
        row_79FC8 = layout.row(heading='Custom', align=False)
        row_79FC8.alert = False
        row_79FC8.enabled = True
        row_79FC8.active = True
        row_79FC8.use_property_split = False
        row_79FC8.use_property_decorate = False
        row_79FC8.scale_x = 1.0
        row_79FC8.scale_y = 1.0
        row_79FC8.alignment = 'Expand'.upper()
        if not True: row_79FC8.operator_context = "EXEC_DEFAULT"
        op = row_79FC8.operator('mesh.loopcut_slide', text='Loop cut', icon_value=0, emboss=True, depress=False)
        op = row_79FC8.operator('mesh.duplicate_move', text='Duplicate Faces', icon_value=0, emboss=True, depress=False)


class SNA_PT_UV_UNWARP_F3BF1(bpy.types.Panel):
    bl_label = 'UV Unwarp'
    bl_idname = 'SNA_PT_UV_UNWARP_F3BF1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_E8808 = layout.row(heading='Custom', align=False)
        row_E8808.alert = False
        row_E8808.enabled = True
        row_E8808.active = True
        row_E8808.use_property_split = False
        row_E8808.use_property_decorate = False
        row_E8808.scale_x = 1.0
        row_E8808.scale_y = 1.0
        row_E8808.alignment = 'Expand'.upper()
        if not True: row_E8808.operator_context = "EXEC_DEFAULT"
        op = row_E8808.operator('uv.smart_project', text='Smart UV', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.reset', text='Reset', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.unwrap', text='UV Unwarp', icon_value=0, emboss=True, depress=False)
        row_1A9D4 = layout.row(heading='Custom', align=False)
        row_1A9D4.alert = False
        row_1A9D4.enabled = True
        row_1A9D4.active = True
        row_1A9D4.use_property_split = False
        row_1A9D4.use_property_decorate = False
        row_1A9D4.scale_x = 1.0
        row_1A9D4.scale_y = 1.0
        row_1A9D4.alignment = 'Expand'.upper()
        if not True: row_1A9D4.operator_context = "EXEC_DEFAULT"
        op = row_1A9D4.operator('uv.project_from_view', text='View', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = False
        op = row_1A9D4.operator('uv.project_from_view', text='View (Bounds)', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = True
        row_75840 = layout.row(heading='Custom', align=False)
        row_75840.alert = False
        row_75840.enabled = True
        row_75840.active = True
        row_75840.use_property_split = False
        row_75840.use_property_decorate = False
        row_75840.scale_x = 1.0
        row_75840.scale_y = 1.0
        row_75840.alignment = 'Expand'.upper()
        if not True: row_75840.operator_context = "EXEC_DEFAULT"
        op = row_75840.operator('mesh.mark_seam', text='Mark Seam', icon_value=0, emboss=True, depress=False)
        op = row_75840.operator('mesh.mark_seam', text='Clear Seam', icon_value=0, emboss=True, depress=False)
        op.clear = True
        row_09EC4 = layout.row(heading='Custom', align=False)
        row_09EC4.alert = False
        row_09EC4.enabled = True
        row_09EC4.active = True
        row_09EC4.use_property_split = False
        row_09EC4.use_property_decorate = False
        row_09EC4.scale_x = 1.0
        row_09EC4.scale_y = 1.0
        row_09EC4.alignment = 'Expand'.upper()
        if not True: row_09EC4.operator_context = "EXEC_DEFAULT"
        op = row_09EC4.operator('uv.cube_project', text='Cube Project', icon_value=0, emboss=True, depress=False)
        op = row_09EC4.operator('uv.sphere_project', text='Sphere Project', icon_value=0, emboss=True, depress=False)


class SNA_PT_QUICK_EFFECTS_E6EE9(bpy.types.Panel):
    bl_label = 'Quick Effects'
    bl_idname = 'SNA_PT_QUICK_EFFECTS_E6EE9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_95567 = layout.row(heading='Custom', align=False)
        row_95567.alert = False
        row_95567.enabled = True
        row_95567.active = True
        row_95567.use_property_split = False
        row_95567.use_property_decorate = False
        row_95567.scale_x = 1.0
        row_95567.scale_y = 1.0
        row_95567.alignment = 'Expand'.upper()
        if not True: row_95567.operator_context = "EXEC_DEFAULT"
        op = row_95567.operator('object.quick_fur', text='Fur', icon_value=474, emboss=True, depress=False)
        op = row_95567.operator('object.quick_explode', text='Explode', icon_value=348, emboss=True, depress=False)
        row_5EDBD = layout.row(heading='Custom', align=False)
        row_5EDBD.alert = False
        row_5EDBD.enabled = True
        row_5EDBD.active = True
        row_5EDBD.use_property_split = False
        row_5EDBD.use_property_decorate = False
        row_5EDBD.scale_x = 1.0
        row_5EDBD.scale_y = 1.0
        row_5EDBD.alignment = 'Expand'.upper()
        if not True: row_5EDBD.operator_context = "EXEC_DEFAULT"
        op = row_5EDBD.operator('object.quick_smoke', text='Smoke', icon_value=472, emboss=True, depress=False)
        op = row_5EDBD.operator('object.quick_liquid', text='Liquid', icon_value=478, emboss=True, depress=False)


class SNA_PT_ADD_OBJECTS_018A0(bpy.types.Panel):
    bl_label = 'Add Objects'
    bl_idname = 'SNA_PT_ADD_OBJECTS_018A0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_6E670 = layout.row(heading='Custom', align=False)
        row_6E670.alert = False
        row_6E670.enabled = True
        row_6E670.active = True
        row_6E670.use_property_split = False
        row_6E670.use_property_decorate = False
        row_6E670.scale_x = 1.0
        row_6E670.scale_y = 1.0
        row_6E670.alignment = 'Expand'.upper()
        if not True: row_6E670.operator_context = "EXEC_DEFAULT"
        op = row_6E670.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = row_6E670.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = row_6E670.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        row_E324D = layout.row(heading='Custom', align=False)
        row_E324D.alert = False
        row_E324D.enabled = True
        row_E324D.active = True
        row_E324D.use_property_split = False
        row_E324D.use_property_decorate = False
        row_E324D.scale_x = 1.0
        row_E324D.scale_y = 1.0
        row_E324D.alignment = 'Expand'.upper()
        if not True: row_E324D.operator_context = "EXEC_DEFAULT"
        op = row_E324D.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = row_E324D.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)
        op = row_E324D.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)
        row_BCFD3 = layout.row(heading='Custom', align=False)
        row_BCFD3.alert = False
        row_BCFD3.enabled = True
        row_BCFD3.active = True
        row_BCFD3.use_property_split = False
        row_BCFD3.use_property_decorate = False
        row_BCFD3.scale_x = 1.0
        row_BCFD3.scale_y = 1.0
        row_BCFD3.alignment = 'Expand'.upper()
        if not True: row_BCFD3.operator_context = "EXEC_DEFAULT"
        op = row_BCFD3.operator('object.light_add', text='Light source', icon_value=239, emboss=True, depress=False)
        op = row_BCFD3.operator('object.armature_add', text='Armature', icon_value=174, emboss=True, depress=False)
        op = row_BCFD3.operator('object.camera_add', text='Camera', icon_value=240, emboss=True, depress=False)
        row_E93EC = layout.row(heading='Custom', align=False)
        row_E93EC.alert = False
        row_E93EC.enabled = True
        row_E93EC.active = True
        row_E93EC.use_property_split = False
        row_E93EC.use_property_decorate = False
        row_E93EC.scale_x = 1.0
        row_E93EC.scale_y = 1.0
        row_E93EC.alignment = 'Expand'.upper()
        if not True: row_E93EC.operator_context = "EXEC_DEFAULT"
        op = row_E93EC.operator('mesh.primitive_monkey_add', text='Monkey', icon_value=292, emboss=True, depress=False)
        op = row_E93EC.operator('mesh.primitive_grid_add', text='Grid', icon_value=291, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_4F62F(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_4F62F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_8924B = layout.row(heading='Custom', align=False)
        row_8924B.alert = False
        row_8924B.enabled = True
        row_8924B.active = True
        row_8924B.use_property_split = False
        row_8924B.use_property_decorate = False
        row_8924B.scale_x = 1.0
        row_8924B.scale_y = 1.5
        row_8924B.alignment = 'Expand'.upper()
        if not True: row_8924B.operator_context = "EXEC_DEFAULT"
        op = row_8924B.operator('object.shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        op = row_8924B.operator('object.shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        row_33FCD = layout.row(heading='Custom', align=False)
        row_33FCD.alert = False
        row_33FCD.enabled = True
        row_33FCD.active = True
        row_33FCD.use_property_split = False
        row_33FCD.use_property_decorate = False
        row_33FCD.scale_x = 1.0
        row_33FCD.scale_y = 1.0
        row_33FCD.alignment = 'Expand'.upper()
        if not True: row_33FCD.operator_context = "EXEC_DEFAULT"
        op = row_33FCD.operator('object.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_551D7 = layout.row(heading='Custom', align=False)
        row_551D7.alert = False
        row_551D7.enabled = True
        row_551D7.active = True
        row_551D7.use_property_split = False
        row_551D7.use_property_decorate = False
        row_551D7.scale_x = 1.0
        row_551D7.scale_y = 1.0
        row_551D7.alignment = 'Expand'.upper()
        if not True: row_551D7.operator_context = "EXEC_DEFAULT"
        op = row_551D7.operator('object.convert', text='Convert To', icon_value=0, emboss=True, depress=False)
        row_57631 = layout.row(heading='Custom', align=False)
        row_57631.alert = False
        row_57631.enabled = True
        row_57631.active = True
        row_57631.use_property_split = False
        row_57631.use_property_decorate = False
        row_57631.scale_x = 1.0
        row_57631.scale_y = 1.0
        row_57631.alignment = 'Expand'.upper()
        if not True: row_57631.operator_context = "EXEC_DEFAULT"
        op = row_57631.operator('object.duplicate_move', text='Duplicate', icon_value=0, emboss=True, depress=False)
        op = row_57631.operator('object.duplicate_move_linked', text='Duplicate (Linked)', icon_value=0, emboss=True, depress=False)


class SNA_PT_RELATIONS_D2723(bpy.types.Panel):
    bl_label = 'Relations'
    bl_idname = 'SNA_PT_RELATIONS_D2723'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_FEE98 = layout.row(heading='Custom', align=False)
        row_FEE98.alert = False
        row_FEE98.enabled = True
        row_FEE98.active = True
        row_FEE98.use_property_split = False
        row_FEE98.use_property_decorate = False
        row_FEE98.scale_x = 1.0
        row_FEE98.scale_y = 1.0
        row_FEE98.alignment = 'Expand'.upper()
        if not True: row_FEE98.operator_context = "EXEC_DEFAULT"
        op = row_FEE98.operator('object.make_single_user', text='Make Single User', icon_value=0, emboss=True, depress=False)
        op = row_FEE98.operator('object.make_local', text='Make Local User', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_smooth_shade = bpy.props.StringProperty(name='Smooth Shade', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_85B53)
    bpy.types.TOPBAR_HT_upper_bar.append(sna_add_to_topbar_ht_upper_bar_10CBC)
    bpy.utils.register_class(SNA_PT_CABINETS_B8B3F)
    bpy.utils.register_class(SNA_PT_ADD_OBJECTS_D6F40)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_C0293)
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_UV_UNWARP_F3BF1)
    bpy.utils.register_class(SNA_PT_QUICK_EFFECTS_E6EE9)
    bpy.utils.register_class(SNA_PT_ADD_OBJECTS_018A0)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_4F62F)
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_RELATIONS_D2723)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_smooth_shade
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_85B53)
    bpy.types.TOPBAR_HT_upper_bar.remove(sna_add_to_topbar_ht_upper_bar_10CBC)
    bpy.utils.unregister_class(SNA_PT_CABINETS_B8B3F)
    bpy.utils.unregister_class(SNA_PT_ADD_OBJECTS_D6F40)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_C0293)
    bpy.utils.unregister_class(SNA_PT_UV_UNWARP_F3BF1)
    bpy.utils.unregister_class(SNA_PT_QUICK_EFFECTS_E6EE9)
    bpy.utils.unregister_class(SNA_PT_ADD_OBJECTS_018A0)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_4F62F)
    bpy.utils.unregister_class(SNA_PT_RELATIONS_D2723)
