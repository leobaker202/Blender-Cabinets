# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Blender Cabinets",
    "author" : "Leo Baker", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 3),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Cabinets" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def sna_add_to_view3d_mt_editor_menus_85348(self, context):
    if not (False):
        layout = self.layout
        if (bpy.context.region.alignment == 'TOP'):
            pass


def sna_add_to_topbar_ht_upper_bar_0E9DA(self, context):
    if not (False):
        layout = self.layout
        if (None == None):
            pass


class SNA_PT_CABINETS_CC73F(bpy.types.Panel):
    bl_label = 'Cabinets'
    bl_idname = 'SNA_PT_CABINETS_CC73F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Blender Cabinets'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_EDITING_OPTIONS_99414(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_99414'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_ARMATURE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_34BC2 = layout.row(heading='Custom', align=False)
        row_34BC2.alert = False
        row_34BC2.enabled = True
        row_34BC2.active = True
        row_34BC2.use_property_split = False
        row_34BC2.use_property_decorate = False
        row_34BC2.scale_x = 1.0
        row_34BC2.scale_y = 1.0
        row_34BC2.alignment = 'Expand'.upper()
        if not True: row_34BC2.operator_context = "EXEC_DEFAULT"
        op = row_34BC2.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        op = row_34BC2.operator('armature.symmetrize', text='Symmetrize', icon_value=0, emboss=True, depress=False)
        row_F17EE = layout.row(heading='Custom', align=False)
        row_F17EE.alert = False
        row_F17EE.enabled = True
        row_F17EE.active = True
        row_F17EE.use_property_split = False
        row_F17EE.use_property_decorate = False
        row_F17EE.scale_x = 1.0
        row_F17EE.scale_y = 1.0
        row_F17EE.alignment = 'Expand'.upper()
        if not True: row_F17EE.operator_context = "EXEC_DEFAULT"
        op = row_F17EE.operator('armature.roll_clear', text='Clear bone roll', icon_value=0, emboss=True, depress=False)
        row_ADBC0 = layout.row(heading='Custom', align=False)
        row_ADBC0.alert = False
        row_ADBC0.enabled = True
        row_ADBC0.active = True
        row_ADBC0.use_property_split = False
        row_ADBC0.use_property_decorate = False
        row_ADBC0.scale_x = 1.0
        row_ADBC0.scale_y = 1.0
        row_ADBC0.alignment = 'Expand'.upper()
        if not True: row_ADBC0.operator_context = "EXEC_DEFAULT"
        op = row_ADBC0.operator('armature.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        row_FE484 = layout.row(heading='Custom', align=False)
        row_FE484.alert = False
        row_FE484.enabled = True
        row_FE484.active = True
        row_FE484.use_property_split = False
        row_FE484.use_property_decorate = False
        row_FE484.scale_x = 1.0
        row_FE484.scale_y = 1.0
        row_FE484.alignment = 'Expand'.upper()
        if not True: row_FE484.operator_context = "EXEC_DEFAULT"
        op = row_FE484.operator('armature.switch_direction', text='Switch direction', icon_value=0, emboss=True, depress=False)
        row_E548E = layout.row(heading='Custom', align=False)
        row_E548E.alert = False
        row_E548E.enabled = True
        row_E548E.active = True
        row_E548E.use_property_split = False
        row_E548E.use_property_decorate = False
        row_E548E.scale_x = 1.0
        row_E548E.scale_y = 1.0
        row_E548E.alignment = 'Expand'.upper()
        if not True: row_E548E.operator_context = "EXEC_DEFAULT"
        op = row_E548E.operator('armature.autoside_names', text='Auto-Name by Axis', icon_value=0, emboss=True, depress=False)
        row_3632C = layout.row(heading='Change Bone name', align=False)
        row_3632C.alert = False
        row_3632C.enabled = True
        row_3632C.active = True
        row_3632C.use_property_split = False
        row_3632C.use_property_decorate = False
        row_3632C.scale_x = 1.0
        row_3632C.scale_y = 1.0
        row_3632C.alignment = 'Expand'.upper()
        if not True: row_3632C.operator_context = "EXEC_DEFAULT"
        row_3632C.prop(bpy.context.active_bone.id_data.edit_bones.active, 'name', text='', icon_value=0, emboss=True)
        row_82DC6 = layout.row(heading='Bone roll', align=False)
        row_82DC6.alert = False
        row_82DC6.enabled = True
        row_82DC6.active = True
        row_82DC6.use_property_split = False
        row_82DC6.use_property_decorate = False
        row_82DC6.scale_x = 1.0
        row_82DC6.scale_y = 1.0
        row_82DC6.alignment = 'Expand'.upper()
        if not True: row_82DC6.operator_context = "EXEC_DEFAULT"
        row_82DC6.prop(bpy.context.active_bone.id_data.edit_bones.active, 'roll', text='', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'use_deform', text='Use Deform', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone, 'envelope_distance', text='Envolope distance', icon_value=0, emboss=True, expand=False, slider=False, toggle=False)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'envelope_weight', text='Envelope Weight', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'head_radius', text='Head Radius', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone.id_data.bones.active, 'tail_radius', text='Tail Radius', icon_value=0, emboss=True)


class SNA_PT_RELATIONS_54FAD(bpy.types.Panel):
    bl_label = 'Relations'
    bl_idname = 'SNA_PT_RELATIONS_54FAD'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_ARMATURE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.active_bone, 'use_connect', text='Connected', icon_value=0, emboss=True)
        layout.prop(bpy.context.active_bone, 'parent', text='Parent', icon_value=0, emboss=True)


class SNA_PT_ADD_OBJECTS_3F86F(bpy.types.Panel):
    bl_label = 'Add Objects'
    bl_idname = 'SNA_PT_ADD_OBJECTS_3F86F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_C5496 = layout.row(heading='Custom', align=False)
        row_C5496.alert = False
        row_C5496.enabled = True
        row_C5496.active = True
        row_C5496.use_property_split = False
        row_C5496.use_property_decorate = False
        row_C5496.scale_x = 1.0
        row_C5496.scale_y = 1.0
        row_C5496.alignment = 'Expand'.upper()
        if not True: row_C5496.operator_context = "EXEC_DEFAULT"
        op = row_C5496.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = row_C5496.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = row_C5496.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        row_0299B = layout.row(heading='Custom', align=False)
        row_0299B.alert = False
        row_0299B.enabled = True
        row_0299B.active = True
        row_0299B.use_property_split = False
        row_0299B.use_property_decorate = False
        row_0299B.scale_x = 1.0
        row_0299B.scale_y = 1.0
        row_0299B.alignment = 'Expand'.upper()
        if not True: row_0299B.operator_context = "EXEC_DEFAULT"
        op = row_0299B.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = row_0299B.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)
        op = row_0299B.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)


class SNA_PT_UV_UNWRAP_A21EC(bpy.types.Panel):
    bl_label = 'UV unwrap'
    bl_idname = 'SNA_PT_UV_UNWRAP_A21EC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_E8808 = layout.row(heading='Custom', align=False)
        row_E8808.alert = False
        row_E8808.enabled = True
        row_E8808.active = True
        row_E8808.use_property_split = False
        row_E8808.use_property_decorate = False
        row_E8808.scale_x = 1.0
        row_E8808.scale_y = 1.0
        row_E8808.alignment = 'Expand'.upper()
        if not True: row_E8808.operator_context = "EXEC_DEFAULT"
        op = row_E8808.operator('uv.unwrap', text='UV Unwrap', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.smart_project', text='Smart UV', icon_value=0, emboss=True, depress=False)
        op = row_E8808.operator('uv.reset', text='Reset', icon_value=0, emboss=True, depress=False)
        row_1A9D4 = layout.row(heading='Custom', align=False)
        row_1A9D4.alert = False
        row_1A9D4.enabled = True
        row_1A9D4.active = True
        row_1A9D4.use_property_split = False
        row_1A9D4.use_property_decorate = False
        row_1A9D4.scale_x = 1.0
        row_1A9D4.scale_y = 1.0
        row_1A9D4.alignment = 'Expand'.upper()
        if not True: row_1A9D4.operator_context = "EXEC_DEFAULT"
        op = row_1A9D4.operator('uv.project_from_view', text='View', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = False
        op = row_1A9D4.operator('uv.project_from_view', text='View (Bounds)', icon_value=0, emboss=True, depress=False)
        op.scale_to_bounds = True
        row_75840 = layout.row(heading='Custom', align=False)
        row_75840.alert = False
        row_75840.enabled = True
        row_75840.active = True
        row_75840.use_property_split = False
        row_75840.use_property_decorate = False
        row_75840.scale_x = 1.0
        row_75840.scale_y = 1.0
        row_75840.alignment = 'Expand'.upper()
        if not True: row_75840.operator_context = "EXEC_DEFAULT"
        op = row_75840.operator('mesh.mark_seam', text='Mark Seam', icon_value=0, emboss=True, depress=False)
        op = row_75840.operator('mesh.mark_seam', text='Clear Seam', icon_value=0, emboss=True, depress=False)
        op.clear = True
        row_09EC4 = layout.row(heading='Custom', align=False)
        row_09EC4.alert = False
        row_09EC4.enabled = True
        row_09EC4.active = True
        row_09EC4.use_property_split = False
        row_09EC4.use_property_decorate = False
        row_09EC4.scale_x = 1.0
        row_09EC4.scale_y = 1.0
        row_09EC4.alignment = 'Expand'.upper()
        if not True: row_09EC4.operator_context = "EXEC_DEFAULT"
        op = row_09EC4.operator('uv.cube_project', text='Cube Project', icon_value=0, emboss=True, depress=False)
        op = row_09EC4.operator('uv.sphere_project', text='Sphere Project', icon_value=0, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_8631F(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_8631F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_08AF8 = layout.row(heading='Custom', align=False)
        row_08AF8.alert = False
        row_08AF8.enabled = True
        row_08AF8.active = True
        row_08AF8.use_property_split = False
        row_08AF8.use_property_decorate = False
        row_08AF8.scale_x = 1.0
        row_08AF8.scale_y = 1.2000000476837158
        row_08AF8.alignment = 'Expand'.upper()
        if not True: row_08AF8.operator_context = "EXEC_DEFAULT"
        op = row_08AF8.operator('mesh.faces_shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        op = row_08AF8.operator('mesh.faces_shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        row_C9C37 = layout.row(heading='Custom', align=False)
        row_C9C37.alert = False
        row_C9C37.enabled = True
        row_C9C37.active = True
        row_C9C37.use_property_split = False
        row_C9C37.use_property_decorate = False
        row_C9C37.scale_x = 1.0
        row_C9C37.scale_y = 1.0
        row_C9C37.alignment = 'Expand'.upper()
        if not True: row_C9C37.operator_context = "EXEC_DEFAULT"
        op = row_C9C37.operator('mesh.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_58E09 = layout.row(heading='Custom', align=False)
        row_58E09.alert = False
        row_58E09.enabled = True
        row_58E09.active = True
        row_58E09.use_property_split = False
        row_58E09.use_property_decorate = False
        row_58E09.scale_x = 1.0
        row_58E09.scale_y = 1.0
        row_58E09.alignment = 'Expand'.upper()
        if not True: row_58E09.operator_context = "EXEC_DEFAULT"
        op = row_58E09.operator('mesh.flip_normals', text='Flip Normals', icon_value=0, emboss=True, depress=False)
        row_C08C8 = layout.row(heading='Custom', align=False)
        row_C08C8.alert = False
        row_C08C8.enabled = True
        row_C08C8.active = True
        row_C08C8.use_property_split = False
        row_C08C8.use_property_decorate = False
        row_C08C8.scale_x = 1.0
        row_C08C8.scale_y = 1.0
        row_C08C8.alignment = 'Expand'.upper()
        if not True: row_C08C8.operator_context = "EXEC_DEFAULT"
        op = row_C08C8.operator('mesh.merge', text='Merge Polys', icon_value=0, emboss=True, depress=False)
        op = row_C08C8.operator('mesh.split', text='Split Polys', icon_value=0, emboss=True, depress=False)
        row_6236D = layout.row(heading='Custom', align=False)
        row_6236D.alert = False
        row_6236D.enabled = True
        row_6236D.active = True
        row_6236D.use_property_split = False
        row_6236D.use_property_decorate = False
        row_6236D.scale_x = 1.0
        row_6236D.scale_y = 1.0
        row_6236D.alignment = 'Expand'.upper()
        if not True: row_6236D.operator_context = "EXEC_DEFAULT"
        op = row_6236D.operator('view3d.edit_mesh_extrude_move_normal', text='Extrude', icon_value=0, emboss=True, depress=False)
        op = row_6236D.operator('mesh.fill', text='Fill', icon_value=0, emboss=True, depress=False)
        row_5CB8C = layout.row(heading='Custom', align=False)
        row_5CB8C.alert = False
        row_5CB8C.enabled = True
        row_5CB8C.active = True
        row_5CB8C.use_property_split = False
        row_5CB8C.use_property_decorate = False
        row_5CB8C.scale_x = 1.0
        row_5CB8C.scale_y = 1.0
        row_5CB8C.alignment = 'Expand'.upper()
        if not True: row_5CB8C.operator_context = "EXEC_DEFAULT"
        op = row_5CB8C.operator('mesh.quads_convert_to_tris', text='Quads to Tris', icon_value=0, emboss=True, depress=False)
        op = row_5CB8C.operator('mesh.tris_convert_to_quads', text='Tris to Quads', icon_value=0, emboss=True, depress=False)
        row_B40A3 = layout.row(heading='Custom', align=False)
        row_B40A3.alert = False
        row_B40A3.enabled = True
        row_B40A3.active = True
        row_B40A3.use_property_split = False
        row_B40A3.use_property_decorate = False
        row_B40A3.scale_x = 1.0
        row_B40A3.scale_y = 1.0
        row_B40A3.alignment = 'Expand'.upper()
        if not True: row_B40A3.operator_context = "EXEC_DEFAULT"
        op = row_B40A3.operator('mesh.vertices_smooth', text='Smooth Vert', icon_value=0, emboss=True, depress=False)
        op = row_B40A3.operator('transform.vert_crease', text='Vertex Crease', icon_value=0, emboss=True, depress=False)
        row_989A1 = layout.row(heading='Custom', align=False)
        row_989A1.alert = False
        row_989A1.enabled = True
        row_989A1.active = True
        row_989A1.use_property_split = False
        row_989A1.use_property_decorate = False
        row_989A1.scale_x = 1.0
        row_989A1.scale_y = 1.0
        row_989A1.alignment = 'Expand'.upper()
        if not True: row_989A1.operator_context = "EXEC_DEFAULT"
        op = row_989A1.operator('mesh.bevel', text='Bevel', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.screw', text='Screw', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.poke', text='Poke', icon_value=0, emboss=True, depress=False)
        op = row_989A1.operator('mesh.solidify', text='Solidify', icon_value=0, emboss=True, depress=False)
        row_E2C0C = layout.row(heading='Custom', align=False)
        row_E2C0C.alert = False
        row_E2C0C.enabled = True
        row_E2C0C.active = True
        row_E2C0C.use_property_split = False
        row_E2C0C.use_property_decorate = False
        row_E2C0C.scale_x = 1.0
        row_E2C0C.scale_y = 1.0
        row_E2C0C.alignment = 'Expand'.upper()
        if not True: row_E2C0C.operator_context = "EXEC_DEFAULT"
        op = row_E2C0C.operator('mesh.subdivide', text='Subdivide', icon_value=0, emboss=True, depress=False)
        op = row_E2C0C.operator('mesh.unsubdivide', text='Un-Subdivide', icon_value=0, emboss=True, depress=False)
        row_79FC8 = layout.row(heading='Custom', align=False)
        row_79FC8.alert = False
        row_79FC8.enabled = True
        row_79FC8.active = True
        row_79FC8.use_property_split = False
        row_79FC8.use_property_decorate = False
        row_79FC8.scale_x = 1.0
        row_79FC8.scale_y = 1.0
        row_79FC8.alignment = 'Expand'.upper()
        if not True: row_79FC8.operator_context = "EXEC_DEFAULT"
        op = row_79FC8.operator('mesh.loopcut_slide', text='Loop cut', icon_value=0, emboss=True, depress=False)
        op = row_79FC8.operator('mesh.duplicate_move', text='Duplicate Faces', icon_value=0, emboss=True, depress=False)
        row_9E720 = layout.row(heading='Custom', align=False)
        row_9E720.alert = False
        row_9E720.enabled = True
        row_9E720.active = True
        row_9E720.use_property_split = False
        row_9E720.use_property_decorate = False
        row_9E720.scale_x = 1.0
        row_9E720.scale_y = 1.0
        row_9E720.alignment = 'Expand'.upper()
        if not True: row_9E720.operator_context = "EXEC_DEFAULT"
        op = row_9E720.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)


class SNA_PT_SHORTCUTS_DC944(bpy.types.Panel):
    bl_label = 'Shortcuts'
    bl_idname = 'SNA_PT_SHORTCUTS_DC944'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_47F4D = layout.row(heading='', align=False)
        row_47F4D.alert = False
        row_47F4D.enabled = True
        row_47F4D.active = True
        row_47F4D.use_property_split = False
        row_47F4D.use_property_decorate = False
        row_47F4D.scale_x = 1.0
        row_47F4D.scale_y = 1.0
        row_47F4D.alignment = 'Expand'.upper()
        if not True: row_47F4D.operator_context = "EXEC_DEFAULT"
        row_47F4D.prop(bpy.context.area.spaces[0].overlay, 'show_face_orientation', text='Face Direction', icon_value=0, emboss=True)
        row_47F4D.prop(bpy.context.area.spaces[0].overlay, 'show_stats', text='Statistics', icon_value=0, emboss=True)
        row_83D9A = layout.row(heading='', align=False)
        row_83D9A.alert = False
        row_83D9A.enabled = True
        row_83D9A.active = True
        row_83D9A.use_property_split = False
        row_83D9A.use_property_decorate = False
        row_83D9A.scale_x = 1.0
        row_83D9A.scale_y = 1.0
        row_83D9A.alignment = 'Expand'.upper()
        if not True: row_83D9A.operator_context = "EXEC_DEFAULT"
        op = row_83D9A.operator('object.mode_set', text='', icon_value=48, emboss=True, depress=False)
        op.mode = 'OBJECT'
        op = row_83D9A.operator('object.mode_set', text='', icon_value=444, emboss=True, depress=False)
        op.mode = 'EDIT'
        if bpy.context.view_layer.objects.active.type == 'MESH':
            op = row_83D9A.operator('object.mode_set', text='', icon_value=910, emboss=True, depress=False)
            op.mode = 'VERTEX_PAINT'
        if bpy.context.view_layer.objects.active.type == 'MESH':
            op = row_83D9A.operator('object.mode_set', text='', icon_value=908, emboss=True, depress=False)
            op.mode = 'TEXTURE_PAINT'
            op.toggle = False


class SNA_PT_MAIN_OBJECT_PROPERTIES_3570A(bpy.types.Panel):
    bl_label = 'Main Object Properties'
    bl_idname = 'SNA_PT_MAIN_OBJECT_PROPERTIES_3570A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='Rotate', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.objects.active, 'scale', text='Scale', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.objects.active, 'name', text='Name', icon_value=0, emboss=True)


class SNA_PT_QUICK_EFFECTS_81BBB(bpy.types.Panel):
    bl_label = 'Quick Effects'
    bl_idname = 'SNA_PT_QUICK_EFFECTS_81BBB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_95567 = layout.row(heading='Custom', align=False)
        row_95567.alert = False
        row_95567.enabled = True
        row_95567.active = True
        row_95567.use_property_split = False
        row_95567.use_property_decorate = False
        row_95567.scale_x = 1.0
        row_95567.scale_y = 1.0
        row_95567.alignment = 'Expand'.upper()
        if not True: row_95567.operator_context = "EXEC_DEFAULT"
        op = row_95567.operator('object.quick_fur', text='Fur', icon_value=474, emboss=True, depress=False)
        op = row_95567.operator('object.quick_explode', text='Explode', icon_value=348, emboss=True, depress=False)
        row_5EDBD = layout.row(heading='Custom', align=False)
        row_5EDBD.alert = False
        row_5EDBD.enabled = True
        row_5EDBD.active = True
        row_5EDBD.use_property_split = False
        row_5EDBD.use_property_decorate = False
        row_5EDBD.scale_x = 1.0
        row_5EDBD.scale_y = 1.0
        row_5EDBD.alignment = 'Expand'.upper()
        if not True: row_5EDBD.operator_context = "EXEC_DEFAULT"
        op = row_5EDBD.operator('object.quick_smoke', text='Smoke', icon_value=472, emboss=True, depress=False)
        op = row_5EDBD.operator('object.quick_liquid', text='Liquid', icon_value=478, emboss=True, depress=False)


class SNA_PT_ADD_OBJECTS_747DF(bpy.types.Panel):
    bl_label = 'Add Objects'
    bl_idname = 'SNA_PT_ADD_OBJECTS_747DF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_6E670 = layout.row(heading='Custom', align=False)
        row_6E670.alert = False
        row_6E670.enabled = True
        row_6E670.active = True
        row_6E670.use_property_split = False
        row_6E670.use_property_decorate = False
        row_6E670.scale_x = 1.0
        row_6E670.scale_y = 1.0
        row_6E670.alignment = 'Expand'.upper()
        if not True: row_6E670.operator_context = "EXEC_DEFAULT"
        op = row_6E670.operator('mesh.primitive_cube_add', text='Cube', icon_value=287, emboss=True, depress=False)
        op = row_6E670.operator('mesh.primitive_uv_sphere_add', text='Sphere', icon_value=289, emboss=True, depress=False)
        op = row_6E670.operator('mesh.primitive_plane_add', text='Plane', icon_value=286, emboss=True, depress=False)
        row_E324D = layout.row(heading='Custom', align=False)
        row_E324D.alert = False
        row_E324D.enabled = True
        row_E324D.active = True
        row_E324D.use_property_split = False
        row_E324D.use_property_decorate = False
        row_E324D.scale_x = 1.0
        row_E324D.scale_y = 1.0
        row_E324D.alignment = 'Expand'.upper()
        if not True: row_E324D.operator_context = "EXEC_DEFAULT"
        op = row_E324D.operator('mesh.primitive_cone_add', text='Cone', icon_value=305, emboss=True, depress=False)
        op = row_E324D.operator('mesh.primitive_cylinder_add', text='Cylinder', icon_value=310, emboss=True, depress=False)
        op = row_E324D.operator('mesh.primitive_torus_add', text='Torus', icon_value=294, emboss=True, depress=False)
        row_BCFD3 = layout.row(heading='Custom', align=False)
        row_BCFD3.alert = False
        row_BCFD3.enabled = True
        row_BCFD3.active = True
        row_BCFD3.use_property_split = False
        row_BCFD3.use_property_decorate = False
        row_BCFD3.scale_x = 1.0
        row_BCFD3.scale_y = 1.0
        row_BCFD3.alignment = 'Expand'.upper()
        if not True: row_BCFD3.operator_context = "EXEC_DEFAULT"
        op = row_BCFD3.operator('object.light_add', text='Light source', icon_value=239, emboss=True, depress=False)
        op = row_BCFD3.operator('object.armature_add', text='Armature', icon_value=174, emboss=True, depress=False)
        op = row_BCFD3.operator('object.camera_add', text='Camera', icon_value=240, emboss=True, depress=False)
        row_E93EC = layout.row(heading='Custom', align=False)
        row_E93EC.alert = False
        row_E93EC.enabled = True
        row_E93EC.active = True
        row_E93EC.use_property_split = False
        row_E93EC.use_property_decorate = False
        row_E93EC.scale_x = 1.0
        row_E93EC.scale_y = 1.0
        row_E93EC.alignment = 'Expand'.upper()
        if not True: row_E93EC.operator_context = "EXEC_DEFAULT"
        op = row_E93EC.operator('mesh.primitive_monkey_add', text='Monkey', icon_value=292, emboss=True, depress=False)
        op = row_E93EC.operator('mesh.primitive_grid_add', text='Grid', icon_value=291, emboss=True, depress=False)


class SNA_PT_RELATIONS_99FB0(bpy.types.Panel):
    bl_label = 'Relations'
    bl_idname = 'SNA_PT_RELATIONS_99FB0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_FEE98 = layout.row(heading='Custom', align=False)
        row_FEE98.alert = False
        row_FEE98.enabled = True
        row_FEE98.active = True
        row_FEE98.use_property_split = False
        row_FEE98.use_property_decorate = False
        row_FEE98.scale_x = 1.0
        row_FEE98.scale_y = 1.0
        row_FEE98.alignment = 'Expand'.upper()
        if not True: row_FEE98.operator_context = "EXEC_DEFAULT"
        op = row_FEE98.operator('object.make_single_user', text='Make Single User', icon_value=0, emboss=True, depress=False)
        op = row_FEE98.operator('object.make_local', text='Make Local User', icon_value=0, emboss=True, depress=False)


class SNA_PT_EDITING_OPTIONS_55B00(bpy.types.Panel):
    bl_label = 'Editing Options'
    bl_idname = 'SNA_PT_EDITING_OPTIONS_55B00'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CABINETS_CC73F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'OBJECT'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_8924B = layout.row(heading='Custom', align=False)
        row_8924B.alert = False
        row_8924B.enabled = True
        row_8924B.active = True
        row_8924B.use_property_split = False
        row_8924B.use_property_decorate = False
        row_8924B.scale_x = 1.0
        row_8924B.scale_y = 1.200000286102295
        row_8924B.alignment = 'Expand'.upper()
        if not True: row_8924B.operator_context = "EXEC_DEFAULT"
        op = row_8924B.operator('object.shade_smooth', text='Smooth Shading', icon_value=_icons['smoothshade.png'].icon_id, emboss=True, depress=False)
        op = row_8924B.operator('object.shade_flat', text='Flat Shading', icon_value=_icons['flatshade.png'].icon_id, emboss=True, depress=False)
        row_33FCD = layout.row(heading='Custom', align=False)
        row_33FCD.alert = False
        row_33FCD.enabled = True
        row_33FCD.active = True
        row_33FCD.use_property_split = False
        row_33FCD.use_property_decorate = False
        row_33FCD.scale_x = 1.0
        row_33FCD.scale_y = 1.0
        row_33FCD.alignment = 'Expand'.upper()
        if not True: row_33FCD.operator_context = "EXEC_DEFAULT"
        op = row_33FCD.operator('object.select_all', text='Select or Deselect All Objects', icon_value=0, emboss=True, depress=False)
        row_551D7 = layout.row(heading='Custom', align=False)
        row_551D7.alert = False
        row_551D7.enabled = True
        row_551D7.active = True
        row_551D7.use_property_split = False
        row_551D7.use_property_decorate = False
        row_551D7.scale_x = 1.0
        row_551D7.scale_y = 1.0
        row_551D7.alignment = 'Expand'.upper()
        if not True: row_551D7.operator_context = "EXEC_DEFAULT"
        op = row_551D7.operator('object.convert', text='Convert To', icon_value=0, emboss=True, depress=False)
        row_A6A0D = layout.row(heading='Custom', align=False)
        row_A6A0D.alert = False
        row_A6A0D.enabled = True
        row_A6A0D.active = True
        row_A6A0D.use_property_split = False
        row_A6A0D.use_property_decorate = False
        row_A6A0D.scale_x = 1.0
        row_A6A0D.scale_y = 1.0
        row_A6A0D.alignment = 'Expand'.upper()
        if not True: row_A6A0D.operator_context = "EXEC_DEFAULT"
        op = row_A6A0D.operator('object.join', text='Join into a single mesh', icon_value=0, emboss=True, depress=False)
        row_57631 = layout.row(heading='Custom', align=False)
        row_57631.alert = False
        row_57631.enabled = True
        row_57631.active = True
        row_57631.use_property_split = False
        row_57631.use_property_decorate = False
        row_57631.scale_x = 1.0
        row_57631.scale_y = 1.0
        row_57631.alignment = 'Expand'.upper()
        if not True: row_57631.operator_context = "EXEC_DEFAULT"
        op = row_57631.operator('object.duplicate_move', text='Duplicate', icon_value=0, emboss=True, depress=False)
        op = row_57631.operator('object.duplicate_move_linked', text='Duplicate (Linked)', icon_value=0, emboss=True, depress=False)
        row_5BA4D = layout.row(heading='Custom', align=False)
        row_5BA4D.alert = False
        row_5BA4D.enabled = True
        row_5BA4D.active = True
        row_5BA4D.use_property_split = False
        row_5BA4D.use_property_decorate = False
        row_5BA4D.scale_x = 1.0
        row_5BA4D.scale_y = 1.0
        row_5BA4D.alignment = 'Expand'.upper()
        if not True: row_5BA4D.operator_context = "EXEC_DEFAULT"
        op = row_5BA4D.operator('transform.mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        op = row_5BA4D.operator('object.origin_set', text='Set Origin', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_smooth_shade = bpy.props.StringProperty(name='Smooth Shade', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_spaceview3dcontext = bpy.props.StringProperty(name='SpaceView3D.context', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_85348)
    bpy.types.TOPBAR_HT_upper_bar.append(sna_add_to_topbar_ht_upper_bar_0E9DA)
    bpy.utils.register_class(SNA_PT_CABINETS_CC73F)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_99414)
    bpy.utils.register_class(SNA_PT_RELATIONS_54FAD)
    bpy.utils.register_class(SNA_PT_ADD_OBJECTS_3F86F)
    bpy.utils.register_class(SNA_PT_UV_UNWRAP_A21EC)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_8631F)
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_SHORTCUTS_DC944)
    bpy.utils.register_class(SNA_PT_MAIN_OBJECT_PROPERTIES_3570A)
    bpy.utils.register_class(SNA_PT_QUICK_EFFECTS_81BBB)
    bpy.utils.register_class(SNA_PT_ADD_OBJECTS_747DF)
    bpy.utils.register_class(SNA_PT_RELATIONS_99FB0)
    bpy.utils.register_class(SNA_PT_EDITING_OPTIONS_55B00)
    if not 'smoothshade.png' in _icons: _icons.load('smoothshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'smoothshade.png'), "IMAGE")
    if not 'flatshade.png' in _icons: _icons.load('flatshade.png', os.path.join(os.path.dirname(__file__), 'icons', 'flatshade.png'), "IMAGE")


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_spaceview3dcontext
    del bpy.types.Scene.sna_smooth_shade
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_85348)
    bpy.types.TOPBAR_HT_upper_bar.remove(sna_add_to_topbar_ht_upper_bar_0E9DA)
    bpy.utils.unregister_class(SNA_PT_CABINETS_CC73F)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_99414)
    bpy.utils.unregister_class(SNA_PT_RELATIONS_54FAD)
    bpy.utils.unregister_class(SNA_PT_ADD_OBJECTS_3F86F)
    bpy.utils.unregister_class(SNA_PT_UV_UNWRAP_A21EC)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_8631F)
    bpy.utils.unregister_class(SNA_PT_SHORTCUTS_DC944)
    bpy.utils.unregister_class(SNA_PT_MAIN_OBJECT_PROPERTIES_3570A)
    bpy.utils.unregister_class(SNA_PT_QUICK_EFFECTS_81BBB)
    bpy.utils.unregister_class(SNA_PT_ADD_OBJECTS_747DF)
    bpy.utils.unregister_class(SNA_PT_RELATIONS_99FB0)
    bpy.utils.unregister_class(SNA_PT_EDITING_OPTIONS_55B00)
